
from odoo import models, fields, api

class WizardButton(models.Model):

    _inherit = 'sale.order'

    # customer_reference = fields.Char(string="Customer Reference")

